package org.capgemini.dao;

import org.capgemini.dto.Product;

public class ProductDaoImpl implements ProductDao{

	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Product findProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

}
